<template>
  <div class="superAdmin">
    superAdmin
  </div>
</template>

<script>
export default {

}
</script>

<style lang="less" scoped>

</style>