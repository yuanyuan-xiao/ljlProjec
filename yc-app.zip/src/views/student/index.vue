<template>
  <div class="student">
    student
  </div>
</template>

<script>
export default {
  name: ''

}
</script>

<style lang="less" scoped>

</style>