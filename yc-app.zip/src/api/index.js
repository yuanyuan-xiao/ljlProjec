import mockRequest from './mockRequest'


export const mockUser = () => mockRequest.get('user');